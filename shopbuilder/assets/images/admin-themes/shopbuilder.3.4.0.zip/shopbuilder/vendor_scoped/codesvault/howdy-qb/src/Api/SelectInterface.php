<?php

namespace RadiusTheme\SB\Dependencies\CodesVault\Howdyqb\Api;

interface SelectInterface extends WhereClauseInterface
{
    public function distinct(): self;
    public function columns(...$columns): self;
    public function alias(string $name): self;
    public function from(string $table_name): self;
    /**
     * JOIN table(s) ON condition of
     * $col1 and $col2 columns
     *
     * @param string|array $table_name
     * @param string|null $col1
     * @param string|null $col2
     *
     * @return CodesVault\Howdyqb\Api\SelectInterface
     */
    public function join($table_name, ?string $col1 = null, ?string $col2 = null): self;
    /**
     * INNER JOIN table(s) ON condition of
     * $col1 and $col2 columns
     *
     * @param string|array $table_name
     * @param string|null $col1
     * @param string|null $col2
     *
     * @return CodesVault\Howdyqb\Api\SelectInterface
     */
    public function innerJoin($table_name, ?string $col1 = null, ?string $col2 = null): self;
    /**
     * LEFT JOIN table(s) ON condition of
     * $col1 and $col2 columns
     *
     * @param string|array $table_name
     * @param string|null $col1
     * @param string|null $col2
     *
     * @return CodesVault\Howdyqb\Api\SelectInterface
     */
    public function leftJoin($table_name, ?string $col1 = null, ?string $col2 = null): self;
    /**
     * RIGHT JOIN table(s) ON condition of
     * $col1 and $col2 columns
     *
     * @param string|array $table_name
     * @param string|null $col1
     * @param string|null $col2
     *
     * @return CodesVault\Howdyqb\Api\SelectInterface
     */
    public function rightJoin($table_name, ?string $col1 = null, ?string $col2 = null): self;
    /**
     * ORDER BY column(s) with sort direction
     *
     * @param string|array $column
     * @param string $sort
     *
     * @return CodesVault\Howdyqb\Api\SelectInterface
     */
    public function orderBy($column, string $sort = 'ASC'): self;
    public function groupBy($column): self;
    public function limit(int $count): self;
    public function offset(int $count): self;
    public function count(string $column, string $alias = ''): self;
    public function avg(string $column, string $alias = ''): self;
    public function min(string $column, string $alias = ''): self;
    public function max(string $column, string $alias = ''): self;
    public function raw(string $sql): self;
    public function getSql();
    public function get();
}
